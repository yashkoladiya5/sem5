<?php
session_start();
$image_text = substr(str_shuffle(("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")), 0, rand(3, 4));

$_SESSION['captcha'] = $image_text;

$img = imagecreate(250, 50);
$bg = imagecolorallocate($img, 0, 255, 255);
$fg = imagecolorallocate($img, 0, 0, 0);

imagestring($img, 5, 90, 10, $image_text, $fg);
header("Content-type: image/png");

imagepng($img);

imagedestroy($img);
?>