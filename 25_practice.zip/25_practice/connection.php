<?php


$host = '127.0.0.1';
$username = 'root';
$password = '';
$db = 'all_practice';

$conn = mysqli_connect($host, $username, $password, $db);

?>